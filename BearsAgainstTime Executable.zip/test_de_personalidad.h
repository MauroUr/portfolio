#ifndef __TEST_DE_PERSONALIDAD_H__
#define __TEST_DE_PERSONALIDAD_H__


#include <stdio.h>
#include <stdbool.h>
/*
 *  Pre-condiciones:    No tiene.
 *
 *  Post-condiciones:   Le hará una serie de preguntas al usuario y guardará una letra en la variable dependiendo el oso que sea correspondiente.
 */

void test_de_personalidad(char* personalidad_detectada);

#endif /* __TEST_DE_PERSONALIDAD_H__ */