#include <stdio.h>
#include <stdbool.h>
#include "test_de_personalidad.h"

#define ANIME 'A' 
#define MUSICA_POP 'M'
#define LIMPIEZA 'L'

#define BAMBU 'B'
#define PESCADO 'P'
#define FOCAS 'F'

const int MAXIMO_GRITOS = 18, MINIMO_GRITOS = 1;
const int MAXIMO_PISOS = 18, MINIMO_PISOS = 1;

const int MAXIMO_POLAR = 24, MINIMO_POLAR = 5;
const int MAXIMO_PANDA = 43, MINIMO_PANDA = 25;
const int MAXIMO_PARDO = 63, MINIMO_PARDO = 44;

const int MULTIPLICADOR_LIMPIEZA = 1, MULTIPLICADOR_ANIME = 2, MULTIPLICADOR_MUSICA_POP = 3;
const int PUNTAJE_FOCAS = 3, PUNTAJE_BAMBU = 6, PUNTAJE_PESCADO = 9;

const char PANDA = 'P', PARDO = 'G', POLAR = 'I';

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si el canal es válido y false si es inválido.
 */
bool canal_valido(char canal_main){
	return (((canal_main) != ANIME) && ((canal_main) != MUSICA_POP) && ((canal_main) != LIMPIEZA));
}

/*
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez canal_main esté entre ANIME, MUSICA_POP o LIMPIEZA.
 */
void validar_canal(char* canal_main){

		while(canal_valido(*canal_main)){
			printf("\nNo champion, la respuesta es una sola letra en mayúscula, la A por Anime, la M por musica pop y la L por limpieza, a ver dale. ¿Qué canal elegís?  ");
			scanf(" %c", canal_main);
		}
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si el alimento es válido y false si es inválido.
 */
bool alimento_valido(char alimento_main){
	return (((alimento_main) != BAMBU) && ((alimento_main) != PESCADO) && ((alimento_main) != FOCAS));
}

/*	
 *	Pre-condiciones:	No tiene.
 *	Post-condiciones:	Terminará una vez alimento_main esté entre BAMBU, PESCADO o FOCAS.
 */
void validar_alimento(char* alimento_main){

		while(alimento_valido(*alimento_main)){
			printf("\nNo locura, la respuesta es una sola letra en mayúscula, la B por bambú, la P por pescado y la F por focas, vamos. ¿Qué alimento guardas?  ");
			scanf(" %c", alimento_main);
	}
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si el piso es válido y false si es inválido.
 */
bool piso_valido(int piso_main){
	return (((piso_main) > MAXIMO_PISOS) || ((piso_main) < MINIMO_PISOS));
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez piso_main esté entre MAXIMO_PISOS y MINIMO_PISOS.
 */
void validar_piso(int* piso_main){

	while(piso_valido(*piso_main)){
		printf("\nNo pa, si la torre tiene 18 pisos tenes que poner un piso entre 1 y 18, dale de nuevo. ¿En que piso te gustaría vivir?  ");
		scanf("%i", piso_main);
	}
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si el grito es válido y false si es inválido.
 */
bool grito_valido(int grito_main){
	return (((grito_main) > MAXIMO_GRITOS) || ((grito_main) < MINIMO_GRITOS));
}

/*
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez grito_main esté entre MAXIMO_GRITOS y MINIMO_GRITOS.
 */
void validar_grito(int* grito_main){

	while(grito_valido(*grito_main)){
		printf("\nNo master, el volumen del grito tiene que ser entre 1 y 18, probá otra vez. ¿Cuánto gritas por la rata?  ");
		scanf("%i", grito_main);
	}
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez la respuesta del usuario sea válida y la enviará a canal en el main.
 */
void pregunta_canal(char* canal){

	printf("Vas a ver televisión un rato, pones el canal de: Anime (A), Musica Pop (M) o Limpieza(L)? Contestar utilizando las letras en mayúscula.  ");

	scanf(" %c", canal);

	validar_canal(canal);
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez la respuesta del usuario sea válida y la enviará a alimento en el main.
 */
void pregunta_alimento(char* alimento){

	printf("\nSolo podes guardar un alimento en tu vianda: Bambú (B), Pescado (P), Focas (F). Contestar utilizando las letras en mayúscula.  ");

	scanf(" %c", alimento);

	validar_alimento(alimento);
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez la respuesta del usuario sea válida y la enviará a piso en el main.
 */
void pregunta_piso(int* piso){

	printf("\nTe compras una torre con tus dos hermanos de 18 pisos. ¿En que piso te gustaría vivir?  ");

	scanf("%i", piso);

	validar_piso(piso);
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Terminará una vez la respuesta del usuario sea válida y la enviará a grito en el main.
 */
void pregunta_grito(int* grito){

	printf("\n¡Oh, una rata! ¿Que tan fuerte gritas del 1 al 18? Siendo 1 no gritar y 18 desgarrarse la garganta.  ");

	scanf("%i", grito);

	validar_grito(grito);
}

/*
 *	Pre-condiciones: 	-canal entre ANIME, MUSICA_POP o LIMPIEZA. 
 *					 	-alimento entre BAMBU, PESCADO o FOCAS.
 *						-piso entre MAXIMO_PISOS y MINIMO_PISOS.
 *						-grito entre MAXIMO_GRITOS Y MINIMO_GRITOS.
 *
 *	Post-condiciones:	Devolverá el puntaje total correspondiente a las respuestas del usuario.
 */
int calcular_puntaje(char respuesta_canal, char respuesta_alimento, int respuesta_piso, int respuesta_grito){

	int multiplicador_canal, puntaje_alimento;

	switch(respuesta_canal){

		case ANIME: 
			multiplicador_canal = MULTIPLICADOR_ANIME;
			break;

		case LIMPIEZA:
			multiplicador_canal = MULTIPLICADOR_LIMPIEZA;
			break;

		case MUSICA_POP:
			multiplicador_canal = MULTIPLICADOR_MUSICA_POP;
			break;

	}
	switch(respuesta_alimento){

		case FOCAS: 
			puntaje_alimento = PUNTAJE_FOCAS;
			break;

		case BAMBU:
			puntaje_alimento = PUNTAJE_BAMBU;
			break;

		case PESCADO:
			puntaje_alimento = PUNTAJE_PESCADO;
			break;

	}
	
	return ((puntaje_alimento * multiplicador_canal) + respuesta_piso + respuesta_grito);
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si es polar y false si no lo es.
 */
bool es_polar(int puntaje_total){
	return ((puntaje_total >= MINIMO_POLAR) && (puntaje_total <= MAXIMO_POLAR));
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si es panda y false si no lo es.
 */
bool es_panda(int puntaje_total){
	return ((puntaje_total >= MINIMO_PANDA) && (puntaje_total <= MAXIMO_PANDA));
}

/*	
 *	Pre-condiciones:	No tiene.
 *
 *	Post-condiciones:	Devolverá true si es pardo y false si no lo es.
 */
bool es_pardo(int puntaje_total){
	return ((puntaje_total >= MINIMO_PARDO) && (puntaje_total <= MAXIMO_PARDO));
}

/*	
 *	Pre-condiciones:	Deberá recibir un puntaje entre 5 y 63 inclusive.
 *
 *	Post-condiciones:	El programa muestra en pantalla el animal que corresponde a las respuestas del usuario.
 */
char cual_oso(int puntaje_total){

	if(es_polar(puntaje_total)){
		return POLAR;	
	}else if(es_panda(puntaje_total)){
		return PANDA;
	}else if(es_pardo(puntaje_total)){
		return PARDO;
	}
	return 0;
}
/*
 *  Pre-condiciones:    No tiene.
 *
 *  Post-condiciones:   Le hará una serie de preguntas al usuario y guardará una letra en la variable dependiendo el oso que sea correspondiente.
 */
void test_de_personalidad(char* personalidad_detectada){

	char canal, alimento;

	int piso, grito;

	int puntaje;

	pregunta_canal(&canal);

	pregunta_alimento(&alimento);

	pregunta_piso(&piso);

	pregunta_grito(&grito);

	puntaje = calcular_puntaje(canal, alimento, piso, grito); //podría poner esta función directamente en imprimir_tu_oso() y ahorrarme la variable puntaje, pero me parece más fácil de entender de esta manera
	
	(*personalidad_detectada) = cual_oso(puntaje);
}


