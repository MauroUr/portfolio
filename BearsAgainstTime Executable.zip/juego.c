#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include "utiles.h"
#include "osos_contra_reloj.h"
#include "test_de_personalidad.h"
static const char POLAR = 'I', PANDA = 'P', PARDO = 'G';
static const double TIEMPO_TOTAL = 120;
int main(){

	char tipo_personaje;
    int primer_jugada = 0;
    char jugada;
    char empezar;
	juego_t juego;
	test_de_personalidad(&tipo_personaje);
	srand((unsigned int)time(NULL));
	system("clear");
	if(tipo_personaje == POLAR){
		printf("Sos un - Polar (%c) -\n\n", POLAR);
			printf("TERRIBLE!! Tu amiga Chloe se perdio en el bosque y ahora la tenes que rescatar, pero apurate porque es de noche y el covid asecha.\nVas a tener que rescatarla antes de pasados los 120 segundos, vas a tener una mochila con una linterna(10 mov) y velas(5 mov); ademas podes agarrar pilas(+5mov linterna), mas velas o tambien bengalas(3 mov) en el suelo del bosque!\nPero mucho cuidado con chocarte con arboles(A) porque te van a hacer perder tiempo, ni hablar de si te cruzas a uno de esos malvados koalas, te van a sacar del bosque (cada vez que prendes la linterna aparece uno mas!). Al ser un Polar podes saltar las piedras(R) sin problemas :D");	
	}else if(tipo_personaje == PANDA){
		printf("Sos un - Panda (%c) -\n\n", PANDA);
			printf("TERRIBLE!! Tu amiga Chloe se perdio en el bosque y ahora la tenes que rescatar, pero apurate porque es de noche y el covid asecha.\nVas a tener que rescatarla antes de pasados los 120 segundos, vas a tener una mochila con una linterna(10 mov), cinco velas(5 mov) y dos bengalas(3 mov); ademas podes agarrar pilas, mas velas o tambien bengalas en el suelo del bosque!\nPero mucho cuidado con chocarte con piedras(R) o arboles(A) porque te van a hacer perder tiempo, ni hablar de si te cruzas a uno de esos malvados koalas, te van a sacar del bosque (cada vez que prendes la linterna aparece uno mas!)");
	}else if(tipo_personaje == PARDO){
		printf("Sos un - Pardo (%c) -\n\n", PARDO);
			printf("TERRIBLE!! Tu amiga Chloe se perdio en el bosque y ahora la tenes que rescatar, pero apurate porque es de noche y el covid asecha.\nVas a tener que rescatarla antes de pasados los 120 segundos, vas a tener una mochila con una linterna(15 mov) y velas(5 mov); ademas podes agarrar pilas(+5mov linterna), mas velas o tambien bengalas(3 mov) en el suelo del bosque! \nPero mucho cuidado con chocarte con piedras(R) o arboles(A) porque te van a hacer perder tiempo, ni hablar de si te cruzas a uno de esos malvados koalas, te van a sacar del bosque (cada vez que prendes la linterna aparece uno mas!)");
	}
	printf("\n Ingrese CUALQUIER CARACTER para comenzar:");
	scanf(" %c", &empezar);
	inicializar_juego(&juego, tipo_personaje);
	iniciar_cronometro();

	while(estado_juego(juego) == 0){
		printf("\n");
		system("clear");
		mostrar_juego(juego);
	    if(primer_jugada == 0){
	        printf("Los movimientos se realizan utilizando las letras W, A, S, D. Las letras L, V, E, T son para lintera, vela, bengala y tiempo respectivamente.");
	        printf("/n Realizar movimiento:");
	        scanf(" %c", &jugada);
	        primer_jugada++;
	    }else{
	        printf("/n Realizar movimiento (H para recordar controles):");
	        scanf(" %c", &jugada);
	        if(jugada == 'H'){
	            printf("Los movimientos se realizan utilizando las letras W, A, S, D. Las letras L, V, E, T son para lintera, vela, bengala y tiempo respectivamente.");
	            printf("/n Realizar movimiento:");
	            scanf(" %c", &jugada);
	        }
	    }
		while(!(es_jugada_valida(jugada))){
			printf("Por favor, haz una jugada válida (W,A,S,D,L,V,E o T):");
			scanf(" %c", &jugada);
		}
		realizar_jugada(&juego, jugada);

	}
	detener_cronometro();
	mostrar_juego(juego);
	if(juego.personaje.tiempo_perdido < TIEMPO_TOTAL){
		printf("\n GANASTE! \n");
	}else{
		printf("\n PERDISTE :c \n");
	}
}

