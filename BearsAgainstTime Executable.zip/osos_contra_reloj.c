#include <stdlib.h>
#include <stdio.h> 
#include <time.h>
#include <stdbool.h>
#include "osos_contra_reloj.h"
#include "utiles.h"

#define FILAS_MAX 20
#define COL_MAX 30
#define ARRIBA 'W'
#define ABAJO 'S'
#define DERECHA 'D'
#define IZQUIERDA 'A'
#define BENGALA 'E'
#define VELA 'V'
#define LINTERNA 'L'
#define TIEMPO 'T'


const double TIEMPO_TOTAL = 120;
const double T_PERDIDO_ARBOLES = 1, T_PERDIDO_PIEDRAS = 2;

const char PILA = 'B';
const char KOALAS = 'K', ARBOL = 'A', PIEDRA = 'R';
static const char POLAR = 'I', PANDA = 'P', PARDO = 'G', CHLOE = 'C';

const char VACIO = '-';

const int CANT_VELAS_MAPA = 30, CANT_PILAS_MAPA = 30, CANT_ARBOLES_MAPA = 350, CANT_PIEDRAS_MAPA = 80;
const int OBSTACULOS_INICIALES = 431, HERRAMIENTAS_INICIALES = 70;

const int MOV_INIC_LINTERNA = 10, MOV_VELA = 5, MOV_BENGALA = 3, MOV_PILA = 5;

const int JUGANDO = 0, TERMINADO = -1;

// PARA UN ENTENDIMIENTO MÁS ÁGIL DEL CÓDIGO, LAS FUNCIONES AUXILIARES FUERON ORDENADAS ASCENDENTEMENTE POR ORDEN DE APARICIÓN SOBRE LA FUNCION QUE LAS LLAMA

/*
 *
 * Pre-condiciones: fil_rand y col_rand deben tener un valor aleatorio dentro de los límites de FIL_MAX y COL_MAX.
 * 
 * Post-condiciones: Validará que no haya anteriormente una herramienta en el espacio que se quiere ocupar y procederá a asignarle un espacio vacío a la herramienta que reciba.
 *
 */
void validar_y_asignar_posicion_herramientas(elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS] , char tablero_aux[FILAS_MAX][COL_MAX], int fil_rand, int col_rand, int i, char herramienta){
    while(tablero_aux[fil_rand][col_rand] != VACIO){
        
        fil_rand = rand() % FILAS_MAX;
        col_rand = rand() % COL_MAX;
    }
    tablero_aux[fil_rand][col_rand] = herramienta;
    herramientas[i].posicion.fil = fil_rand;
    herramientas[i].posicion.col = col_rand;
}
/*
 *
 * Pre-condiciones: fil_rand y col_rand deben tener un valor aleatorio dentro de los límites de FIL_MAX y COL_MAX.
 * 
 * Post-condiciones: Validará que no haya anteriormente un obstáculo en el espacio que se quiere ocupar y procederá a asignarle un espacio vacío al obstáculo que reciba.
 *
 */
void validar_y_asignar_posicion_obstaculos(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS] , char tablero_aux[FILAS_MAX][COL_MAX], int fil_rand, int col_rand, int i, char obstaculo){
    while(tablero_aux[fil_rand][col_rand] != VACIO){      
        fil_rand = rand() % FILAS_MAX;
        col_rand = rand() % COL_MAX;
    }

    tablero_aux[fil_rand][col_rand] = obstaculo;
    obstaculos[i].posicion.fil = fil_rand;
    obstaculos[i].posicion.col = col_rand;
}
/*
 *
 * Pre-condiciones: Se le debe haber asignado una coordenada al personaje y a chloe anteriormente.
 * 
 * Post-condiciones: Inicializará todos los valores iniciales que tendrá la matriz del juego.
 *
 */
void inicializar_mapa(juego_t* juego){
    char tablero_aux[FILAS_MAX][COL_MAX];
    for (int i = 0; i < FILAS_MAX; ++i){
        for (int j = 0; j < COL_MAX; ++j){
            tablero_aux[i][j] = VACIO;
        }
    }
    tablero_aux[(juego -> personaje.posicion.fil)][(juego -> personaje.posicion.col)] = (juego -> personaje.tipo);
    tablero_aux[(juego -> amiga_chloe.fil)][(juego -> amiga_chloe.col)] = CHLOE;
    juego -> cantidad_obstaculos = OBSTACULOS_INICIALES;
    juego -> cantidad_herramientas = HERRAMIENTAS_INICIALES;

    for (int i = 0; i < (juego -> cantidad_obstaculos); ++i){
        
        int fil_rand = rand() % FILAS_MAX;
        int col_rand = rand() % COL_MAX;

        if(i < CANT_ARBOLES_MAPA){
            juego -> obstaculos[i].tipo = ARBOL;
            validar_y_asignar_posicion_obstaculos((juego -> obstaculos), tablero_aux, fil_rand, col_rand, i, ARBOL);

        }else if(i < (CANT_ARBOLES_MAPA + CANT_PIEDRAS_MAPA)){
            juego -> obstaculos[i].tipo = PIEDRA;
            validar_y_asignar_posicion_obstaculos((juego -> obstaculos), tablero_aux, fil_rand, col_rand, i, PIEDRA);   

        }else{
            juego -> obstaculos[i].tipo = KOALAS;
            validar_y_asignar_posicion_obstaculos((juego -> obstaculos), tablero_aux, fil_rand, col_rand, i, KOALAS);

        }
    }
    for (int j = 0; j < (juego -> cantidad_herramientas); ++j){
        
        int fil_rand = rand() % FILAS_MAX;
        int col_rand = rand() % COL_MAX;

        if(j < CANT_VELAS_MAPA){
            juego -> herramientas[j].tipo = VELA;
            validar_y_asignar_posicion_herramientas((juego -> herramientas), tablero_aux, fil_rand, col_rand, j, VELA);

        }else if(j < (CANT_VELAS_MAPA + CANT_PILAS_MAPA)){
            juego -> herramientas[j].tipo = PILA;
            validar_y_asignar_posicion_herramientas((juego -> herramientas), tablero_aux, fil_rand, col_rand, j, PILA);
        }else{
            juego -> herramientas[j].tipo = BENGALA;
            validar_y_asignar_posicion_herramientas((juego -> herramientas), tablero_aux, fil_rand, col_rand, j, BENGALA);
        }
    }
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Cargará a la mochila de las herramientas con las que comenzará el usuario el juego, dependiendo de cual sea el oso que le corresponde.
 *
 */
void llenar_mochila(elemento_mochila_t mochila[MAX_HERRAMIENTAS], int* cantidad_elementos, char tipo_personaje){

    mochila[0].tipo = LINTERNA;
    mochila[0].movimientos_restantes = MOV_INIC_LINTERNA;
    mochila[1].tipo = VELA;
    mochila[2].tipo = VELA;
    mochila[3].tipo = VELA;
    mochila[4].tipo = VELA;
    *(cantidad_elementos) = 5;

    if(tipo_personaje == POLAR){
        *(cantidad_elementos) = *(cantidad_elementos) + 2;
        mochila[*(cantidad_elementos) - 2].tipo = VELA;
        mochila[*(cantidad_elementos) - 1].tipo = VELA;
    }else if(tipo_personaje == PANDA){
        *(cantidad_elementos) = *(cantidad_elementos) + 2;
        mochila[*(cantidad_elementos) - 2].tipo = BENGALA;
        mochila[*(cantidad_elementos) - 1].tipo = BENGALA;
    }else if(tipo_personaje == PARDO){
        mochila[0].movimientos_restantes = MOV_INIC_LINTERNA + 5;
    }
    for (int i = 0; i < (*cantidad_elementos); ++i){
        if(mochila[i].tipo == VELA){
            mochila[i].movimientos_restantes = MOV_VELA;
        }else if(mochila[i].tipo == BENGALA){
            mochila[i].movimientos_restantes = MOV_BENGALA;
        }
    }
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Llenará los campos correspondientes al personaje que utilizará el usuario con los valores iniciales.
 *
 */
void crear_personaje(personaje_t* personaje, char tipo_personaje){
   
    personaje -> tipo = tipo_personaje;
    personaje -> posicion.fil = rand() % FILAS_MAX;
    personaje -> posicion.col = 0;
    llenar_mochila((personaje -> mochila), &(personaje -> cantidad_elementos), tipo_personaje);
    personaje -> elemento_en_uso = -1;
    personaje -> tiempo_perdido = 0;
    personaje -> ultimo_movimiento = DERECHA;
}
/*
 *
 * Pre-condiciones: El usuario debe haber contestado satisfactoriamente la encuesta inicial para recibir una letra de las 3 posibles (I, P, G).
 * 
 * Post-condiciones: Inicializará el juego, cargando toda la información inicial y los datos del personaje. 
 * 
 */
void inicializar_juego(juego_t* juego, char tipo_personaje){
    crear_personaje(&(juego -> personaje), tipo_personaje);             
    juego -> amiga_chloe.fil = rand() % FILAS_MAX;
    juego -> amiga_chloe.col = rand() % COL_MAX;
    (juego -> chloe_visible) = false;
    inicializar_mapa(juego);
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá true si la posición del personaje es la misma que la de chloe. Y false en cualquier otro caso.
 *
 */
bool encontre_chloe(coordenada_t p_posicion, coordenada_t amiga_chloe){
    return ((p_posicion.fil == amiga_chloe.fil) && (p_posicion.col == amiga_chloe.col));
}

/*
 * Pre-condiciones: Recibe un juego con todas sus estructuras válidas.
 *
 * Post-condiciones: El juego se dará por terminado, si el personaje encontró a Chloe. 
 * Devolverá:
 * -> 0 si el estado es jugando. 
 * -> -1 si el estado es terminado.
 */

int estado_juego(juego_t juego){
    if(encontre_chloe(juego.personaje.posicion, juego.amiga_chloe)){
        return TERMINADO;
    }
    return JUGANDO;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá la posición del vector de obstaculos donde se encuentra el obstáculo que tiene como coordenadas a i y a j y devolverá -1 si no hay un obstáculo en esa coordenada.
 *
 */
int posicion_obstaculo(int i, int j, elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], int tope_obstaculos){
    int k = 0;
    while(((obstaculos[k].posicion.fil) != i || ((obstaculos[k].posicion.col) != j)) && k < tope_obstaculos){
        k++;
    }
    if((obstaculos[k].posicion.fil) != i || ((obstaculos[k].posicion.col) != j))
        return -1;
    
    return k;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Evualará si el personaje colisionó con algún obstáculo y devolverá los segundos que perdió gracias a eso; en caso de los koalas también cambiará los valores de la posición del personaje a alguno de los iniciales posibles.
 *
 */
double colision_obs_personaje(coordenada_t* posicion_pers, elemento_del_mapa_t obstaculos[MAX_HERRAMIENTAS], int tope_obstaculos, char tipo_personaje){
    int fila = (posicion_pers -> fil);
    int columna = (posicion_pers -> col);

    int pos_elem_del_mapa = posicion_obstaculo(fila, columna, obstaculos, tope_obstaculos);

    if(pos_elem_del_mapa != -1){
        if(obstaculos[pos_elem_del_mapa].tipo == ARBOL){
            if(tipo_personaje == PARDO)
                return (T_PERDIDO_ARBOLES / 2);
            return T_PERDIDO_ARBOLES;
        }else if(obstaculos[pos_elem_del_mapa].tipo == PIEDRA){
            if(tipo_personaje == POLAR)
                return 0;
            return T_PERDIDO_PIEDRAS;
        }else if((obstaculos[pos_elem_del_mapa].tipo == KOALAS)){
            (posicion_pers -> fil) = rand() % FILAS_MAX;
            (posicion_pers -> col) = 0;
        }
    }
    return 0;
}
/*
 *
 * Pre-condiciones: El elemento que se quiere borrar debe ser una posición menor al tope.
 * 
 * Post-condiciones: Eliminará el elemento que esté en la posición deseada y disminuirá el tope en 1.
 *
 */
void borrar_elemento_mapa(elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int* tope_herramientas, int herramienta_a_borrar){
    herramientas[herramienta_a_borrar] = herramientas[*tope_herramientas - 1];
    *tope_herramientas = *tope_herramientas - 1;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá la posición del vector de herramientas donde se encuentra la herramienta que tiene como coordenadas a i y a j y devolverá -1 si no hay una herramienta en esa coordenada.
 *
 */
int posicion_herramienta(int i, int j, elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int tope_herramientas){
    int k = 0;
    while(((herramientas[k].posicion.fil) != i || ((herramientas[k].posicion.col) != j)) && k < tope_herramientas){
        k++;
    }
    if(k == tope_herramientas)
        return -1;
    return k;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Evaluará si el personaje colisionó con alguna herramienta y actuará en consecuencia dependiendo lo que deba suceder (agregando a la mochila o sumando movimientos y borrando del mapa).
 *
 */
void colision_herr_personaje(coordenada_t posicion_pers, elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int* tope_herramientas, elemento_mochila_t mochila[MAX_HERRAMIENTAS], int* tope_mochila){
    int fila = posicion_pers.fil;
    int columna = posicion_pers.col;

    int pos_elem_del_mapa = posicion_herramienta(fila, columna, herramientas, *tope_herramientas);

    if(pos_elem_del_mapa != -1){
        mochila[*tope_mochila].tipo = herramientas[pos_elem_del_mapa].tipo;
        if(herramientas[pos_elem_del_mapa].tipo == VELA){
            mochila[*tope_mochila].movimientos_restantes = MOV_VELA;
            *tope_mochila = *tope_mochila + 1;
        } else if(herramientas[pos_elem_del_mapa].tipo == BENGALA){
            mochila[*tope_mochila].movimientos_restantes = MOV_BENGALA;
            *tope_mochila = *tope_mochila + 1;
        } else{
            mochila[0].movimientos_restantes = mochila[0].movimientos_restantes + MOV_PILA;
        }
        borrar_elemento_mapa(herramientas, tope_herramientas, pos_elem_del_mapa);
    }
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá la distancia manhattan entre las coordenadas recibidas.
 *
 */
int distancia_manhattan(int fil_obj, int col_obj, int fil_rand, int col_rand){
    int distancia;
    distancia = ((abs(fil_rand - fil_obj)) + (abs(col_rand - col_obj)));
    return distancia;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá true si el espacio está iluminado por la vela y false si no lo está.
 *
 */
bool iluminado_por_vela(int fil_obj, int col_obj, int p_fil, int p_col){
    return (((fil_obj == p_fil) && (col_obj == p_col-1)) || ((fil_obj == p_fil) && (col_obj == (p_col+1))) || ((fil_obj == p_fil-1) && (col_obj == p_col-1)) || ((fil_obj == p_fil-1) && (col_obj == p_col)) || ((fil_obj == p_fil-1) && (col_obj == p_col+1)) || ((fil_obj == p_fil+1) && (col_obj == p_col-1)) || ((fil_obj == p_fil+1) && (col_obj == p_col)) || ((fil_obj == p_fil+1) && (col_obj == p_col+1)));
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Revisará qué posiciones debería ver el usuario en este turno y las pondrá en visibles, el resto las hará no visibles.
 *
 */
void actualizar_visibilidad(juego_t* juego){
    int p_fil = (juego -> personaje.posicion.fil);
    int p_col = (juego -> personaje.posicion.col);
    int fil_obj, col_obj;
    int fil_rand;
    int col_rand;
    int elem_en_uso = (juego -> personaje.elemento_en_uso);
    bool prender_bengala = false;

    if((juego -> personaje.mochila[juego -> personaje.elemento_en_uso].tipo == BENGALA))
        prender_bengala = true;
    
    if(prender_bengala && (juego -> personaje.mochila[elem_en_uso].movimientos_restantes == 2)){
        fil_rand = rand() % FILAS_MAX;
        col_rand = rand() % COL_MAX;
    }
    for (int i = 0; i < (juego -> cantidad_herramientas); ++i){
        juego -> herramientas[i].visible = false;
    }
    for (int i = 0; i < (juego -> cantidad_obstaculos); ++i){
        juego -> obstaculos[i].visible = false;
    }

    if((elem_en_uso != -1)){
        for (int i = 0; i < (juego -> cantidad_herramientas); ++i){

            fil_obj = (juego -> herramientas[i].posicion.fil);
            col_obj = (juego -> herramientas[i].posicion.col);
            
            if(juego -> personaje.mochila[elem_en_uso].tipo == VELA){
                if(iluminado_por_vela(fil_obj, col_obj, p_fil, p_col))
                    (juego -> herramientas[i].visible) = true;
            }else if((juego -> personaje.mochila[elem_en_uso].tipo == LINTERNA)){
                switch((juego -> personaje.ultimo_movimiento)){
                    case DERECHA:
                        if(fil_obj == p_fil && col_obj > p_col)
                            (juego -> herramientas[i].visible) = true;
                        break;
                    case IZQUIERDA:
                        if(fil_obj == p_fil && col_obj < p_col)
                            (juego -> herramientas[i].visible) = true;
                        break;  
                    case ARRIBA:
                        if(fil_obj < p_fil && col_obj == p_col)
                            (juego -> herramientas[i].visible) = true;
                        break;
                    case ABAJO:
                        if(fil_obj > p_fil && col_obj == p_col)
                            (juego -> herramientas[i].visible) = true;
                        break; 
                }   
            }else if(prender_bengala){
                if(distancia_manhattan(fil_obj, col_obj, fil_rand, col_rand) <= 3)
                    (juego -> herramientas[i].visible) = true;
            }
        }

        for (int i = 0; i < (juego -> cantidad_obstaculos); ++i){
            
            fil_obj = (juego -> obstaculos[i].posicion.fil);
            col_obj = (juego -> obstaculos[i].posicion.col);
            
            if((juego -> personaje.mochila[elem_en_uso].tipo == VELA)){
                if(iluminado_por_vela(fil_obj, col_obj, p_fil, p_col))
                    (juego -> obstaculos[i].visible) = !(juego -> obstaculos[i].visible);
            }else if((juego -> personaje.mochila[elem_en_uso].tipo == LINTERNA)){
                switch((juego -> personaje.ultimo_movimiento)){
                    case DERECHA:
                        if(fil_obj == p_fil && col_obj > p_col)
                            (juego -> obstaculos[i].visible) = true;
                        break;
                    case IZQUIERDA:
                        if(fil_obj == p_fil && col_obj < p_col)
                            (juego -> obstaculos[i].visible) = true;
                        break;  
                    case ARRIBA:
                        if(fil_obj < p_fil && col_obj == p_col)
                            (juego -> obstaculos[i].visible) = true;
                        break;
                    case ABAJO:
                        if(fil_obj > p_fil && col_obj == p_col)
                            (juego -> obstaculos[i].visible) = true;
                        break;    
                }
            }else if(prender_bengala){
                if(distancia_manhattan(fil_obj, col_obj, fil_rand, col_rand) <= 3)
                    (juego -> obstaculos[i].visible) = true;      
            }
        }
    }
    if(juego -> personaje.tipo == PANDA && (juego -> personaje.tiempo_perdido) > 30)
        juego -> chloe_visible = true;
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Devolverá true si la bengala ya está iluminando alguna parte del mapa, y false si no lo está.
 *
 */
bool bengala_iluminando(char herramienta_prendida, int movimientos_restantes){
    return (herramienta_prendida == BENGALA && movimientos_restantes < 2);
}
/*
 *
 * Pre-condiciones: El usuario debe haber enviado E o V como jugada.
 * 
 * Post-condiciones: Devolverá la posición de la herramienta que prendió, en caso de que pueda prenderla y en caso de que no tenga esa herramienta en su mochila devolverá -1 (que significa que no hay herramientas en uso).
 *
 */
int switch_herramienta(elemento_mochila_t mochila[MAX_HERRAMIENTAS], int tope_mochila, char herramienta_a_prender){
    int i = 0;
    int herramienta_prendida = -1;
    while (i < tope_mochila && herramienta_prendida == -1){
        if(mochila[i].tipo == herramienta_a_prender && mochila[i].movimientos_restantes > 0)
            herramienta_prendida = i;
        i++;
    }
    return herramienta_prendida;
}
/*
 *
 * Pre-condiciones: El usuario debe haber prendido la linterna.
 * 
 * Post-condiciones: Agregará un koala al vector de obstáculos en una posición vacía.
 *
 */
void agregar_koala(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int* tope_obstaculos, int tope_herramientas){
    coordenada_t posicion_koala;
    posicion_koala.fil = rand() % FILAS_MAX;
    posicion_koala.col = rand() % COL_MAX;
    coordenada_t auxiliar[MAX_OBSTACULOS + MAX_HERRAMIENTAS];

    for (int i = 0; i < (*tope_obstaculos + tope_herramientas); ++i)
    {
        if(i < tope_herramientas)
            auxiliar[i] = herramientas[i].posicion;
        else
            auxiliar[i] = obstaculos[i].posicion;
    }

    for (int i = 0; i < (*tope_obstaculos + tope_herramientas); ++i){
        if((auxiliar[i].fil == posicion_koala.fil && auxiliar[i].col == posicion_koala.col)){
            posicion_koala.fil = rand() % FILAS_MAX;
            posicion_koala.col = rand() % COL_MAX;
        }
    }

    if(obstaculos[(*tope_obstaculos) - 1].posicion.fil != posicion_koala.fil || obstaculos[(*tope_obstaculos) - 1].posicion.col != posicion_koala.col){
        obstaculos[*tope_obstaculos].tipo = KOALAS;
        obstaculos[*tope_obstaculos].posicion = posicion_koala;
        *tope_obstaculos = *tope_obstaculos + 1;
    }
}
/*
 *
 * Pre-condiciones: El usuario debe haber hecho una jugada válida (W,A,S,D,V,E,L,T).
 *
 * Post-condiciones: Mueve el personaje en la dirección indicada por el usuario o habilita
 * cualquiera de las herramientas y actualiza el juego según los elementos
 * que haya en el camino del personaje.
 * El juego quedará en un estado válido al terminar el movimiento.
 * El movimiento será:
 * -> W: Si el personaje debe moverse para la arriba.
 * -> A: Si el personaje debe moverse para la izquierda.
 * -> S: Si el personaje debe moverse para la abajo.
 * -> D: Si el personaje debe moverse para la derecha.
 * -> L: Si el personaje quiere encender una linterna.
 * -> V: Si el personaje quiere encender una vela.
 * -> E: Si el personaje quiere encender la bengala.
 * -> T: Si el personaje quiere ver el tiempo restante.
 * En caso de que querer activar una herramienta , y no tenga mas movimientos , no deberá
 * activarse ninguna ventaja.
 * Si se aprieta una tecla de iluminación y esta ya está siendo usada , se desactivará colocando
 * el int elemento_en_uso en -1.
 */
void realizar_jugada(juego_t* juego, char jugada){

    switch(jugada){
        case ARRIBA:
            if(juego -> personaje.posicion.fil != 0)
                juego -> personaje.posicion.fil = (juego -> personaje.posicion.fil) - 1;
            juego -> personaje.ultimo_movimiento = ARRIBA;
            if(juego -> personaje.elemento_en_uso != -1)
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case IZQUIERDA:
            if(juego -> personaje.posicion.col != 0)
                juego -> personaje.posicion.col = (juego -> personaje.posicion.col) - 1;
            juego -> personaje.ultimo_movimiento = IZQUIERDA;
            if(juego -> personaje.elemento_en_uso != -1)
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case ABAJO:
            if(juego -> personaje.posicion.fil != (FILAS_MAX - 1))
                juego -> personaje.posicion.fil = (juego -> personaje.posicion.fil) + 1;
            juego -> personaje.ultimo_movimiento = ABAJO;
            if(juego -> personaje.elemento_en_uso != -1)
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case DERECHA:
            if(juego -> personaje.posicion.col != (COL_MAX - 1))
                juego -> personaje.posicion.col = (juego -> personaje.posicion.col) + 1;
            juego -> personaje.ultimo_movimiento = DERECHA;
            if(juego -> personaje.elemento_en_uso != -1)
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break; 
        case LINTERNA:
            if(juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo != BENGALA){
                if(juego -> personaje.elemento_en_uso != 0 && (juego -> personaje.mochila[0].movimientos_restantes > 0)){
                    (juego -> personaje.elemento_en_uso = 0);
                    agregar_koala((juego -> obstaculos), (juego -> herramientas), &(juego -> cantidad_obstaculos), (juego -> cantidad_herramientas));
                    (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
                }
                else
                    juego -> personaje.elemento_en_uso = -1;
            }else
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case VELA:
            if(juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo != BENGALA){
                if(juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo == VELA)
                    (juego -> personaje.elemento_en_uso) = -1;
                else{
                    (juego -> personaje.elemento_en_uso) = switch_herramienta((juego -> personaje.mochila), (juego -> personaje.cantidad_elementos), VELA);
                    (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
                }
            }else
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case BENGALA:
            if(juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo != BENGALA){
                (juego -> personaje.elemento_en_uso) = switch_herramienta((juego -> personaje.mochila), (juego -> personaje.cantidad_elementos), BENGALA);
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            }else
                (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes) -= 1;
            break;
        case TIEMPO:
            juego -> personaje.ultimo_movimiento = TIEMPO;
            break;
    }

    if((jugada == ARRIBA || jugada == ABAJO || jugada == DERECHA || jugada == IZQUIERDA) && (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo != BENGALA)){
        colision_herr_personaje(juego -> personaje.posicion, juego -> herramientas, &(juego -> cantidad_herramientas), juego -> personaje.mochila, &(juego -> personaje.cantidad_elementos));
        (juego -> personaje.tiempo_perdido) = (juego -> personaje.tiempo_perdido) + (colision_obs_personaje(&(juego -> personaje.posicion), (juego -> obstaculos), (juego -> cantidad_obstaculos), (juego -> personaje.tipo)));
    }  

    if(jugada != TIEMPO && !bengala_iluminando((juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].tipo), (juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes))){
        actualizar_visibilidad(juego);
    }

    if(juego -> personaje.mochila[(juego -> personaje.elemento_en_uso)].movimientos_restantes == 0 && jugada != TIEMPO)
        juego -> personaje.elemento_en_uso = -1; 
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Evaluará si en esa posición del tablero hay un obstáculo.
 *
 */
bool es_obstaculo(char posicion_tablero){
    return (posicion_tablero == PIEDRA || posicion_tablero == ARBOL || posicion_tablero == KOALAS);
}
/*
 *
 * Pre-condiciones: El obstáculo con las coordenadas i y j debe existir en el vector.
 * 
 * Post-condiciones: Devolverá true en caso de que el obstáculo sea visible y false en caso de que no lo sea.
 *
 */
bool es_obstaculo_visible(int i, int j, elemento_del_mapa_t obstaculos[MAX_OBSTACULOS]){  
    int k = 0;
    while((obstaculos[k].posicion.fil) != i || ((obstaculos[k].posicion.col) != j)){
        k++;
    }
    return (obstaculos[k].visible);
}
/*
 *
 * Pre-condiciones: No tiene.
 * 
 * Post-condiciones: Evaluará si en esa posición del tablero hay una herramienta.
 *
 */
bool es_herramienta(char posicion_tablero){
    return (posicion_tablero == VELA || posicion_tablero == BENGALA || posicion_tablero == PILA);
}
/*
 *
 * Pre-condiciones: La herramienta con las coordenadas i y j debe existir en el vector.
 * 
 * Post-condiciones: Devolverá true en caso de que la herramienta sea visible y false en caso de que no lo sea.
 *
 */
bool es_herramienta_visible(int i, int j, elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS]){  
    int k = 0;
    while((herramientas[k].posicion.fil) != i || ((herramientas[k].posicion.col) != j)){
        k++;
    }
    return (herramientas[k].visible);
}
/*
 *
 * Pre-condiciones: Necesitará que los vectores de obstáculos y de herramientas estén llenos correctamente, teniendo cada uno coordenadas distintas en cada una de sus posiciones. 
 * 
 * Post-condiciones: Llenará una matriz de obstáculos, herramientas, del oso correspondiente y chloe.
 *
 */
void cargar_tablero(char tablero[FILAS_MAX][COL_MAX], juego_t* juego){
    coordenada_t pos_aux;

    for (int i = 0; i < FILAS_MAX; ++i){
        for (int j = 0; j < COL_MAX; ++j){
                tablero[i][j] = VACIO;  
        }
    }

    tablero[(juego -> personaje.posicion.fil)][(juego -> personaje.posicion.col)] = (juego -> personaje.tipo);
    tablero[(juego -> amiga_chloe.fil)][(juego -> amiga_chloe.col)] = CHLOE;

    for (int k = 0; k < (juego -> cantidad_obstaculos); ++k){   
        pos_aux = juego -> obstaculos[k].posicion;
        tablero[pos_aux.fil][pos_aux.col] = (juego -> obstaculos[k].tipo);
    }
    for (int k = 0; k < (juego -> cantidad_herramientas); ++k){
        pos_aux = juego -> herramientas[k].posicion;
        tablero[pos_aux.fil][pos_aux.col] = (juego -> herramientas[k].tipo);
    }
}
/*
 *
 * Pre-condiciones: Deben estar todos los valores de visibilidad en true o false según corresponda.
 *
 * Post-condiciones: Mostrará el juego por pantalla.
 * 
 */
void mostrar_juego(juego_t juego){
    char imprimir;
    char tablero[FILAS_MAX][COL_MAX];

    cargar_tablero(tablero, &juego);
    printf("\n");

    for(int i = 0; i < FILAS_MAX; i++){
        for(int j = 0; j < COL_MAX; j++){

            imprimir = VACIO;
            if(es_herramienta(tablero[i][j]) && es_herramienta_visible(i, j, (juego.herramientas)))
                imprimir = tablero[i][j];
            if(es_obstaculo(tablero[i][j]) && es_obstaculo_visible(i, j, (juego.obstaculos)))
                imprimir = tablero[i][j];
            if(tablero[i][j] == CHLOE && juego.chloe_visible == true)
                imprimir = tablero[i][j];
            if((i == (juego.personaje.posicion.fil)) && (j == (juego.personaje.posicion.col)))
                imprimir = juego.personaje.tipo;
            printf(" %c", imprimir);
        }
        printf("\n");
    }
    if(juego.personaje.ultimo_movimiento == TIEMPO){

        if((TIEMPO_TOTAL - ((juego.personaje.tiempo_perdido) + tiempo_actual())) < 0)
            printf("%f\n", 0.0);
        else
            printf("%f\n", (TIEMPO_TOTAL - ((juego.personaje.tiempo_perdido) + tiempo_actual())));
    }

}
/*
 *
 * Pre-condiciones: No tiene.
 *
 * Post-condiciones: Devolvera true en caso de ser una jugada valida (W,A,S,D,L,V,E o T)
 * Devolvera false en caso contrario.
 */
bool es_jugada_valida(char jugada){
    return(jugada == ARRIBA || jugada == ABAJO || jugada == DERECHA || jugada == IZQUIERDA || jugada == LINTERNA || jugada == VELA || jugada == BENGALA || jugada == TIEMPO);
}