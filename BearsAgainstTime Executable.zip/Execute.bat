@echo off
:: This line forces the console to open in the same directory as this .bat file
cd /d "%~dp0"

echo Compiling the game...

:: We use utiles.c instead of utiles.o to make it work on Windows
gcc juego.c osos_contra_reloj.c test_de_personalidad.c utiles.o -o juego.exe -std=c99 -Wall -Wconversion -Werror -lm

:: Check if there was a compilation error
if %errorlevel% neq 0 (
    echo.
    echo Compilation error. Please check your code.
    pause
    exit /b %errorlevel%
)

echo.
echo Compilation successful. Starting game...
echo =======================================
echo.

:: Execute the game
juego.exe

echo.
pause